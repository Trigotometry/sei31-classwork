function setup() {
	createCanvas( windowWidth, windowHeight );

	background( 0 );

	stroke( 255 );

	// relating to circle
	fill( 255, 0, 0 );
	strokeWeight( 2 );
	ellipse( 300, 300, 200, 200 );

	// simple line
	line( 100, 100, 500, 500 );

	// relating to rectangle
	fill( 0, 255, 0 );
	rect(400, 100, 200, 200 );

	// relating to rectangle
}

// function draw() {
//
// }